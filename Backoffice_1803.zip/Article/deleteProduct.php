<?php   include './Class/Functions.php';

    if(isset($_GET['product'])){
      $lstFunctions = new Functions();
      $currentProduct = $lstFunctions->deleteProduct($_GET['product']);
      header("Location: index.php");
    }
