// SI BESOIN D'AJAX

// $('#addProductCateg').click(function(event) {
//
//     event.preventDefault();
//
//     if($("#categName")[0].value.length > 0)
//     {
//       $.ajax({
//         type: 'post',
//         url: 'addProductCateg.php',
//         data: {name: $("#categName")[0].value}
//       });
//       //$('#productCateg').trigger("chosen:updated");
//       $("#productCateg").selectmenu("update", true);
//     }
// });
