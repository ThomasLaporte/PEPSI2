
<?php include "../Class/Functions.php";

    require_once "../header.html";
    $lstFunctions = new Functions();

    if(isset($_GET['categ'])){

      // Si l'utilisateur clic sur le bouton valider apres aviur fait ses modifications
      if(isset($_POST['categName']) && $_POST['categName'] != "")
      {
         if($lstFunctions->updateProductCateg($_GET['categ'], $_POST['categName'], $_POST['categLanguage'])){ // $_POST['productCateg']
           ?> <script>alert("MAJ effectué avec succés ! ");</script> <?php
         }
         else {
           echo "Probleme rencontré lors de l'update";
         }
      }

      $currentCateg = $lstFunctions->getProductCategByID($_GET['categ']);

      $content = "<h2>Modification de la catégorie</h2>";
      $content .= "<form method=\"post\">";
      $content .= "Nom catégorie: <input type=\"text\" name=\"categName\" value=\"". $currentCateg['name']."\"><br>";

      $content .= "Langue: <select name=\"categLanguage\">";
      foreach ($lstFunctions->getLanguages() as $language) {
        $isSelected = "";
        if($language['idlanguage'] == $currentCateg['language_idlanguage']){$isSelected = "Selected";}
        $content .= "<option value=\"".$language['idlanguage']."\"".$isSelected.">".$language['name']."</option>";
      }
      $content .= "</select>";


      $content .="<input type=\"submit\" value=\"Submit\">";
      $content .="</form>";
      echo $content;
    }
  else {
    //header("Location:http://127.0.0.1/PEPSI2-backoffice");
  } ?>
  </body>
</html>
