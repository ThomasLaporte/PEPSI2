<?php   include '../Class/Functions.php';

    if(isset($_GET['categ'])){
      $lstFunctions = new Functions();
      $currentProduct = $lstFunctions->deleteProductCateg($_GET['categ']);
      header("Location: index.php");
    }
