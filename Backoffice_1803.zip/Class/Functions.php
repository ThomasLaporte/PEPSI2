<?php
require_once("DbConnection.php");
require_once("Products.php");
require_once("Manufacturers.php");
require_once("ProductCategs.php");
require_once("Languages.php");

Class Functions{
  // Instanciation de la connexion à la BDD
  private $_DB;
  private $products;
  private $manufacturers;
  private $productCategs;
  private $languages;

  function __construct(){
    $this->_DB = new DbConnection();
    $this->products = new Products($this->_DB);
    $this->manufacturers = new Manufacturers($this->_DB);
    $this->productCategs = new ProductCategs($this->_DB);
    $this->languages = new Languages($this->_DB);
  }

  // Produits
  function getProducts()
  {
    return $this->products->listProducts();
  }
  function getProductByID($id)
  {
    return $this->products->productByID($id);
  }

  function updateProduct($id, $name, $ref, $desc, $quantity, $weight, $dim, $pict, $manuId, $categ)
  {
    return $this->products->updateProduct($id, $name, $ref, $desc, $quantity, $weight, $dim, $pict, $manuId, $categ);
  }

  function deleteProduct($id)
  {
    return $this->products->deleteProduct($id);
  }

  function addProduct($name, $ref, $quantity, $weight, $dim, $pict, $manuId, $categ)
  {
    return $this->products->addProduct($name, $ref, $quantity, $weight, $dim, $pict, $manuId, $categ);
    //$idArticle = $this->products->addProduct($name, $ref, $quantity, $weight, $dim, $pict, $manuId, $categ);
    //$this->products->addCharacteristic($idArticle); // Id Article
  }



  // Fournisseurs
  function getManufacturers()
  {
    return $this->manufacturers->listManufacturers();
  }

  function addManufacturer($name, $adress, $postal, $city, $country)
  {

    return $this->manufacturers->addManufacturer($name, $adress, $postal, $city, $country);
  }

  function deleteManufacturer($id)
  {
    return $this->manufacturers->deleteManufacturer($id);
  }

  // Categorie article
  function addArticleCategorie($name, $code, $idLanguage)
  {
    return $this->productCategs->addArticleCateg($name, $code, $idLanguage);
  }

  function getMaxCodeFromCategProd()
  {
    return $this->productCategs->getLastCodeFromCategProd();
  }

  function getProductsCategs()
  {
    return $this->productCategs->getProductCategs();
  }

  function getProductCategByID($categId)
  {
    return $this->productCategs->getProductCategByID($categId);
  }

  function updateProductCateg($id, $name, $idLanguage)
  {
    return $this->productCategs->updateProductCateg($id, $name, $idLanguage);
  }

  function deleteProductCateg($id)
  {
    return $this->productCategs->deleteProductCateg($id);
  }

  function getProductsCategsByLang($language)
  {
    return $this->productCategs->getProductsCategsByLang($language);
  }

  function getLanguages(){
    return $this->languages->listLanguages();
  }

  function addLanguage($name)
  {
    return $this->languages->addLanguage($name);
  }

  function deleteLanguage($id)
  {
    return $this->languages->deleteLanguage($id);
  }

}
