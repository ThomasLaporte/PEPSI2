<?php

class ProductCategs {
   private $DB;

   function __construct($DB) {
     $this->DB = $DB;
   }

   public function getProductCategs()
   {
     $sql = "SELECT id_article_category, name FROM article_category";
     $sth = $this->DB->query($sql);
     $rowset = $sth->fetchAll(PDO::FETCH_ASSOC);
     return $rowset;
   }

   public function getProductsCategsByLang($idlanguage)
   {
     $sql = "SELECT id_article_category, name FROM article_category WHERE language_idlanguage = :idLanguage";
     $array = array(
       ':idLanguage' => $idlanguage);

     $sth = $this->DB->query($sql, $array);
     $rowset = $sth->fetchAll(PDO::FETCH_ASSOC);
     return $rowset;
   }

   public function getLastCodeFromCategProd()
   {
     $sql = "SELECT MAX(code) FROM article_category";
     $sth = $this->DB->query($sql);
     $rowset = $sth->fetch(PDO::FETCH_ASSOC);
     return $rowset;
   }

   public function addArticleCateg($name, $code, $idLanguage)
   {
     $sql = "INSERT INTO article_category (name, code, language_idlanguage) VALUES (:name, :code, :idLanguage)";

    $array = array(
      ':name' => $name,
      ':code' => $code,
      ':idLanguage' => $idLanguage);

    return $this->DB->query($sql, $array);

   }

   public function getProductCategByID($categID)
   {
     $sql = "SELECT name, code, language_idlanguage FROM article_category WHERE id_article_category = :categId";
     $array = array(
       ':categId' => $categID);

     $sth = $this->DB->query($sql, $array);
     $rowset = $sth->fetchAll(PDO::FETCH_ASSOC);
     return $rowset;
   }

   public function deleteProductCateg($id)
   {
     $sql = "DELETE FROM article_category WHERE id_article_category = :id LIMIT 1";

     $array = array(
       ':id' => $id);

     $this->DB->query($sql, $array);
     return true;
   }

   public function updateProductCateg($id, $name, $idLanguage)
   {
     $sql = "UPDATE article_category SET name = :name, reference = :ref, language_idlanguage = :languageId ".
            "WHERE id_article_category = :id LIMIT 1";

    $array = array(
      ':name' => $name,
      ':languageId' => $idLanguage,
      ':id' => $id);

    $this->DB->query($sql, $array);
    return true;

   }

 }
