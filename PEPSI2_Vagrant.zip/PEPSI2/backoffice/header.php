<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Index</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <ul>
      <li><a href='index.php'>Articles</a></li>
      <li><a href='Manufacturer/lstManufacturers.php'>Fabricants</a></li>
      <li><a href='#'>Catégories article</a></li>
    </ul><br>
