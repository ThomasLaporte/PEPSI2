<?php
if(isset($_GET['categName'])){
  require_once '/Class/Functions.php';
  $lstFunctions = new Functions();

  $lstFunctions->addArticleCategorie($_GET['categName']);

}
header('Location:http://127.0.0.1/pepsi2-backoffice/addProduct.php');
